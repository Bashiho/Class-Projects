public enum Accidental {	
   SHARP, NATURAL, FLAT
}